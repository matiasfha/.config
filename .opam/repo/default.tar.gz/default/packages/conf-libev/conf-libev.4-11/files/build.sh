#!/bin/sh

ocaml discover.ml
